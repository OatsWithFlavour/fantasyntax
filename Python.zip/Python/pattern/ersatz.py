import re

def bereinige_regex(schablone: str) -> str:
    """Entfernt überflüssige Leerzeichen aus dem String."""
    return schablone.replace(" ", "")

def ersetze_values(schablone: str, eintrag: dict) -> str:
    """Ersetzt alle VAL1, VAL2, ... durch deren konkrete Werte (nicht escaped)."""
    for key, value in eintrag.items():
        if key.startswith("VAL"):
            schablone = schablone.replace(key, value)
    return schablone

def ersetze_platzhalter(schablone: str) -> str:
    """Ersetzt Platzhalter #1, #2, ... durch \1, \2, ... (für Ersatz-Strings)."""
    return re.sub(r'#(\d+)', r'\\\1', schablone)

def generiere_ersatz(vorlagen: dict, ersatzdaten: dict) -> dict:
    """
    Erzeugt aus den geladenen JSON-Daten ein Dict mit benannten Ersatz-Strings.
    Rückgabe: {ersatzname: ersatz_str}
    """
    ersatz_dict = {}

    for typ in ['environment', 'command']:
        for eintrag in ersatzdaten.get(typ, []):
            name = eintrag.get("name")
            vorlage_name = eintrag.get("vorlage")
            if not name or not vorlage_name:
                continue

            schablone = vorlagen[typ][vorlage_name]
            schablone = bereinige_regex(schablone)
            schablone = ersetze_values(schablone, eintrag)
            schablone = ersetze_platzhalter(schablone)

            ersatz_dict[name] = schablone

    return ersatz_dict
