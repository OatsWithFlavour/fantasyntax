from config.config_loader import load_config
from helper.io import TextFile
from pattern.muster import generiere_regex
from pattern.ersatz import generiere_ersatz


def main():
    paths = load_config("paths")
    txt_path = paths["txt"]
    tex_path = paths["tex"]
    txt = TextFile(txt_path)
    tex = TextFile(tex_path)
    print(txt.read())
    print(tex.read())

    mapping = load_config("mapping")
    muster_vorlagen = load_config("muster_vorlage")
    musterdaten = load_config("muster")
    regex_dict = generiere_regex(muster_vorlagen, mapping, musterdaten)
    print(regex_dict)

    # NEU: Ersatzausdrücke laden und anzeigen
    ersatz_vorlagen = load_config("ersatz_vorlage")
    ersatzdaten = load_config("ersatz")
    ersatz_dict = generiere_ersatz(ersatz_vorlagen, ersatzdaten)
    
    print(ersatz_dict)

if __name__ == "__main__":
    main()
