def hallo():
    return "hallo"
